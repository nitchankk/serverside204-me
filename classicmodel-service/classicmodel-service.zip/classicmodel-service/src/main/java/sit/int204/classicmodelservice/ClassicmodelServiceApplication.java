package sit.int204.classicmodelservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassicmodelServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClassicmodelServiceApplication.class, args);
    }

}
